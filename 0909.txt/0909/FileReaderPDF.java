package com.cms.syntax.cpp.exp;

import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.pdfbox.text.PDFTextStripperByArea;

/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: FileReaderPDF
 * @Package: com.cms.syntax.cpp.exp ← CMSCodeScanner
 * @Description:
 * @Date 2024年09月08日  20:32
 */
public class FileReaderPDF {


        public static void main(String[] args) {
            try {
                // 加载PDF文件
                File file = new File("D:\\E_RunDB\\20240705\\SiViewModel_LogicalRecipe.pdf");
                PDDocument document = PDDocument.load(file);

                // 提取文本
                PDFTextStripper pdfStripper = new PDFTextStripper();
                String text = pdfStripper.getText(document);
                System.out.println("PDF内容: \n" + text);

                // 关闭文档
                document.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
/*

            try (PDDocument document = PDDocument.load(new File("D:\\E_RunDB\\20240705\\SiViewModel_LogicalRecipe.pdf"))) {
                document.getClass();
                if(!document.isEncrypted()) {
                    PDFTextStripperByArea stripper = new PDFTextStripperByArea();
                    stripper.setSortByPosition(true);
                    PDFTextStripper tStripper = new PDFTextStripper();

                    String pdfFileInText = tStripper.getText(document);
                    System.out.println(pdfFileInText);
                    String[] lines = pdfFileInText.split("\\r?\\n");
                    for(String line : lines) {
                        System.out.println(line);
                    }

                }
            } catch (InvalidPasswordException e) {
                e.printStackTrace();
            } catch (IOException e) {

                e.printStackTrace();
            }
*/
        }

    }