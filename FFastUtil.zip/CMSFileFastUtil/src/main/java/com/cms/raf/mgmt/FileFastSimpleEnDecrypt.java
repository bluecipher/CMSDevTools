package com.cms.raf.mgmt;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.Key;

/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: TestEnDecrypt
 * @Package: org.cxmt.btit.br ← CxmtCMS
 * @Description:
 * @Date 2023年08月11日  18:02
 */
public class FileFastSimpleEnDecrypt {
    private static final String ALGORITHM = "AES";

    private static final String KEY = "1234432109877890"; // 16, 24, or 32 bytes

    public static String path1 = "Q:\\E_JavaBanch\\tmp\\cmp_01.cms";   //src
    public static String path2 = "Q:\\E_JavaBanch\\tmp\\cmp_02.cms";  //src En
    public static String path3 = "Q:\\E_JavaBanch\\tmp\\cmp_03.cms";  //src De
    public static String path4 = "Q:\\E_JavaBanch\\tmp\\bts_cmp_txt.txt"; //src --> En--> Mutiline
    public static String path5= "Q:\\E_JavaBanch\\tmp\\cmp_05.cms";   // En Multiline --> Srl obj
    public static String path6= "Q:\\E_JavaBanch\\tmp\\cmp_06.cms";  // obj --> src

    public static void main(String[] args) throws Exception {
/*
        String absPath = "Q:\\E_RunDB\\ob\\FastSimpleEnDecrypt.java";
        String ss[] = {
                "Q:\\E_RunDB\\ob\\fk_log_tmp_01_03_06.7z_seg_001.dat",
                "Q:\\E_RunDB\\ob\\fk_log_tmp_01_03_06.7z_seg_002.dat",
                "Q:\\E_RunDB\\ob\\fk_log_tmp_01_03_06.7z_seg_003.dat",
                "Q:\\E_RunDB\\ob\\fk_log_tmp_01_03_06.7z_seg_004.dat"
        } ;
        for (int i = 0; i < ss.length ; i++) {
            doRecycle( ss[i]);
        }*/
        String ss[] = {
//                "D:\\E_RunDB\\20240705\\kds-nommoc-BE.z7_seg_001.dat.en.ml",
//                "D:\\E_RunDB\\20240705\\kds-nommoc-BE.z7_seg_002.dat.en.ml",
//                "D:\\E_RunDB\\20240705\\kds-nommoc-BE.z7_seg_003.dat.en.ml",
//                "D:\\E_RunDB\\20240705\\kds-nommoc-BE.z7_seg_004.dat.en.ml"
                   //"D:\\E_RunDB\\20240705\\CMS_2324_001.dat.en.ml",
                   //"D:\\E_RunDB\\20240705\\CMS_2324_002.dat.en.ml"
                 // "D:\\E_RunDB\\20240705\\0822_CodeReview\\08222.txt"
                  //"D:\\E_RunDB\\0829\\0829_1947.aa"
                 // "D:\\E_RunDB\\20240705\\0830\\pizPwSp.piz.en.ml",
//                "D:\\E_RunDB\\0906\\1.1.ml",
//                "D:\\E_RunDB\\0906\\1.2.1.ml",
//                "D:\\E_RunDB\\0906\\1.2.2.ml",
//                "D:\\E_RunDB\\0906\\1.2.3.ml",
//                "D:\\E_RunDB\\0906\\1.2.4.ml",
//                "D:\\E_RunDB\\0906\\1.3.1.ml",
//                "D:\\E_RunDB\\0906\\1.3.2.ml",
//                "D:\\E_RunDB\\0906\\1.3.3.ml",
//                "D:\\E_RunDB\\0906\\1.3.4.ml",
//                "D:\\E_RunDB\\0906\\1.3.5.ml",
//                "D:\\E_RunDB\\0906\\1.3.6.ml",
//                "D:\\E_RunDB\\0906\\1.3.7.ml",
//                "D:\\E_RunDB\\0906\\1.5.1.ml",
//                "D:\\E_RunDB\\0906\\1.5.2.ml",
//                "D:\\E_RunDB\\0906\\1.5.3.ml",
//                "D:\\E_RunDB\\0906\\1.5.c.1.ml",
//                "D:\\E_RunDB\\0906\\1.5.c.2.ml",
//                "D:\\E_RunDB\\0906\\1.5.c.3.ml"
                  //"D:\\E_RunDB\\0906\\tmp.gz.en.ml"
               // "D:\\E_RunDB\\0909\\sv_laun_ch_pw.txt",
               // "D:\\E_RunDB\\0913\\aaa_bbb.raj.en.ml",
                "D:\\E_RunDB\\20240705\\0912_output_test\\aaa.zip.ml.ml"
        } ;
        for (int i = 0; i < ss.length ; i++) {
            String absPathEnML =ss[i]  ;
            String  absPathRtrSrc = retriveMatrix(absPathEnML);
            String  absPathCycDe = decryptFile(KEY ,  absPathRtrSrc);
        }

    }

    public static byte[]  makeMLTxtByBytes(String absPathEn , byte[] bts ) {

        byte[] enbytes = null ;
        try {
            byte[] keyBytes = KEY.getBytes("UTF-8");
            Key secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            enbytes = encryptBytes(secretKey, bts);
            makeMatrixByBytes( absPathEn ,  enbytes) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return enbytes  ;
    }


    public static String  doRecycle(String absPath) throws Exception {
        String absPathEn = doEncrypt(absPath);
        String absPathEnML =  makeMatrix(absPathEn) ;
        String  absPathRtrSrc = retriveMatrix(absPathEnML);
        String  absPathCycDe = decryptFile(KEY ,  absPathRtrSrc);
        return absPathCycDe ;
    }

    public static String  doEncrypt(String absPathSrc ) {
        String absPathEn = absPathSrc +".en" ;
        String absPathDe = absPathSrc +".de";
        String inputFile =absPathSrc ;
        String encryptedFile = absPathEn ;
        String decryptedFile =absPathDe ;

        try {
            byte[] keyBytes = KEY.getBytes("UTF-8");
            Key secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            // Encrypt the file
            encryptFile(secretKey, inputFile, encryptedFile);
            // Decrypt the file
            decryptFile(secretKey, encryptedFile, decryptedFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return absPathEn  ;
    }

    public static String makeMatrix(String absPathEn) throws IOException {
        String absPathEnML= absPathEn +".ml" ;
        Path path = Paths.get(absPathEn);
        PrintWriter pw = new PrintWriter(absPathEnML) ;
        byte[] bts = Files.readAllBytes(path);
        for (int i = 0; i < bts.length; i++) {
            System.out.println(bts[i]);
            pw.print(bts[i]+" ");
            if((i+1)%100==0){
                pw.println();
            }
        }
        pw.close();
        return absPathEnML ;
    }

    public static String makeMatrixByBytes(String absPathEn , byte[] bts) throws IOException {
        String absPathEnML= absPathEn +".ml" ;
        PrintWriter pw = new PrintWriter(absPathEnML) ;
        for (int i = 0; i < bts.length; i++) {
            pw.print(bts[i]+" ");
            if((i+1)%100==0){
                pw.println();
            }
        }
        pw.close();
        return absPathEnML ;
    }


    public static String  retriveMatrix(String absPathEnML) throws IOException {
        String absPathRtrSrc =absPathEnML +".rtsrc";

        FileReader fr =new FileReader(absPathEnML) ;
        BufferedReader br =new BufferedReader(fr) ;
        String line = null ;
        StringBuffer sb =new StringBuffer() ;
        while((line=br.readLine()) != null){
            sb.append(line) ;
        }
        line = sb.toString();
        String[] ss = line.split("[ \\t]+") ;
        byte[] bts =new byte[ss.length] ;
        for (int i = 0; i < ss.length; i++) {
            bts[i] = Byte.parseByte(ss[i]);
        }
        RandomAccessFile raf = new RandomAccessFile(absPathRtrSrc ,"rw");
        raf.write(bts);
        raf.close() ;
        return absPathRtrSrc ;
    }

    private static void encryptFile(Key key, String inputFile, String outputFile) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] inputBytes = Files.readAllBytes(Paths.get(inputFile));
        byte[] encryptedBytes = cipher.doFinal(inputBytes);

        Files.write(Paths.get(outputFile), encryptedBytes, StandardOpenOption.CREATE);
        System.out.println("File encrypted successfully.");
    }

    private static byte[] encryptBytes(Key key,  byte[] inputBytes) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] encryptedBytes = cipher.doFinal(inputBytes);

        System.out.println("File encrypted successfully.");
        return encryptedBytes;
    }

    private static void decryptFile(Key key, String inputFile, String outputFile) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);

        byte[] encryptedBytes = Files.readAllBytes(Paths.get(inputFile));
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        Files.write(Paths.get(outputFile), decryptedBytes, StandardOpenOption.CREATE);
        System.out.println("File decrypted successfully.");
    }

    private static byte[]  decryptBytes(Key key, byte[] encryptedBytes) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, key);

        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        System.out.println("File decrypted successfully.");
        return decryptedBytes ;
    }

    public static String decryptFile(String  keyStr, String inputFile) throws Exception {
        String outputFile = inputFile + ".cyc.de" ;
        byte[] keyBytes = KEY.getBytes("UTF-8");
        Key secretKey = new SecretKeySpec(keyBytes, ALGORITHM);

        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);

        byte[] encryptedBytes = Files.readAllBytes(Paths.get(inputFile));
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

        Files.write(Paths.get(outputFile), decryptedBytes, StandardOpenOption.CREATE);
        System.out.println("File decrypted successfully.");
        return outputFile ;
    }

    public static String getKEY() {
        return KEY;
    }
}

