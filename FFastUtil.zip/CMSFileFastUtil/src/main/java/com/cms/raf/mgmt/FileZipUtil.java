package com.cms.raf.mgmt;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.compress.archivers.zip.ZipMethod;
import org.apache.commons.compress.utils.IOUtils;
/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: ZipUtil
 * @Package: com.cms.syntax.cpp.exp ← CppScanner
 * @Description:
 * @Date 2024年08月27日  0:54
 */
public class FileZipUtil {
    public static void main(String[] args) throws IOException, FileNotFoundException {

    }


    // apache lib  ...压缩文件或文件夹，支持选择压缩级别（0-9）和压缩方式（STORED/DEFLATED）
    public static byte[] compressFileToZipByApache(File fileToZip,  int compressionLevel, ZipMethod method) {
        byte[] bts = null ;
        ByteArrayOutputStream baos = null;
        ZipArchiveOutputStream zipOut = null;

        try {
            baos = new ByteArrayOutputStream();
            zipOut = (ZipArchiveOutputStream) new ArchiveStreamFactory().createArchiveOutputStream(ArchiveStreamFactory.ZIP, baos);

            // 设置压缩级别
            zipOut.setLevel(compressionLevel);

            // 设置压缩方式
            zipOut.setMethod(method.getCode()); // STORED = 0, DEFLATED = 8


            if (fileToZip.isFile()) {
                addFileToZip(fileToZip, "", zipOut);  // 压缩单个文件
            }
            else if (fileToZip.isDirectory()) {
                for (File file : fileToZip.listFiles()) {
                    addFileToZip(file, fileToZip.getName() + "/", zipOut); // 递归压缩目录
                }
            }
            bts =baos.toByteArray() ;
            System.out.println("zipping complete -->: " + fileToZip.getAbsolutePath());
        } catch (Exception e) {
            System.err.println("压缩过程中出错: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (zipOut != null) {
                    zipOut.finish();
                    zipOut.close();
                }
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException e) {
                System.err.println("关闭资源时出错: " + e.getMessage());
            }
        }
        return bts ;
    }
    // apache lib ... 递归添加文件/目录到 ZIP 文件
    private static void addFileToZip(File file, String parentDirectoryName, ArchiveOutputStream zipOut) throws IOException {
        String entryName = parentDirectoryName + file.getName();
        ZipArchiveEntry zipEntry = new ZipArchiveEntry(file, entryName);
        zipOut.putArchiveEntry(zipEntry);

        if (file.isFile()) {
            FileInputStream fis = null;
            try {
                System.out.println("zipping file -->" +file.getAbsolutePath());
                fis = new FileInputStream(file);
                IOUtils.copy(fis, zipOut);  // 复制文件流到 ZIP
            } finally {
                if (fis != null) {
                    fis.close();  // 手动关闭文件流
                }
            }
            zipOut.closeArchiveEntry();
        }
        else if (file.isDirectory()) {
            zipOut.closeArchiveEntry();
            for (File childFile : file.listFiles()) {
                addFileToZip(childFile, entryName + "/", zipOut);  // 递归添加子文件
            }
        }
    }



    public static byte[] zip2Mem(String absZipDir) throws IOException {
        int compressLevel = 7;  // 设置压缩级别
        ZipMethod compressMethod = ZipMethod.DEFLATED;  // 设置压缩方式，使用 DEFLATED

        File fileToZip = new File(absZipDir);
       // zipDirectory( fileToZip , fileToZip.getName()  , zos);
        byte[] bts = compressFileToZipByApache(fileToZip ,compressLevel , compressMethod) ;
        return bts ;
    }


    // 方法用于压缩单个文件
    public static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
        if (fileToZip.isHidden()) {
            return; // 跳过隐藏文件
        }
        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);

        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) > 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }

// 压缩文件夹或文件
 public static void zipDirectory(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
     if (fileToZip.isHidden()) {
         return;
     }
     System.out.println("iter-->"+fileToZip.getAbsolutePath());
     if (fileToZip.isDirectory()) {
         if (fileName.endsWith("/")) {
             zipOut.putNextEntry(new ZipEntry(fileName));
             zipOut.closeEntry();
         } else {
             zipOut.putNextEntry(new ZipEntry(fileName + "/"));
             zipOut.closeEntry();
         }
         File[] children = fileToZip.listFiles();
         for (File childFile : children) {
             zipDirectory(childFile, fileName + "/" + childFile.getName(), zipOut);
         }
         return;
     }
     zipFile(fileToZip, fileName, zipOut);
 }


    public static void unzipFile(String fileZip , File destDir) throws IOException {
        //被解压的压缩文件
         //fileZip = "D:\\E_RunDB\\dirCompressed.zip";
        //解压的目标目录
         //destDir = new File("D:\\E_RunDB\\unzip");

        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(fileZip));
        //获取压缩包中的entry，并将其解压
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            File newFile = newFile(destDir, zipEntry);
            FileOutputStream fos = new FileOutputStream(newFile);
            int len;
            while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            //解压完成一个entry，再解压下一个
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }
    //在解压目标文件夹，新建一个文件
    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("该解压项在目标文件夹之外: " + zipEntry.getName());
        }

        return destFile;
    }
}
