package com.cms.raf.mgmt;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.zip.Deflater;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: FileListCopy
 * @Package: com.cms.syntax.cpp.exp ← CppScanner
 * @Description:
 * @Date 2024年08月27日  22:21
 */
public class FileListCopy {
    private static final String ALGORITHM = "AES";
    private static final int KEY_SIZE = 128;

    private static final String ALGORITHM2 = "PBEWithMD5AndDES";
    private static final int ITERATION_COUNT = 1000;


    public static void main(String[] args) throws IOException, GeneralSecurityException {
        String dir = "D:\\E_RunDB\\20240705\\0822_CodeReview\\0821";
        //recListFiles(dir);
        //copyByList();
        //zipByCrypt();
        //unzipByCrypt();
        //zipByCryptSpec();
        // zipByLevel();

        //unzipByCryptSpec();
        //unzipOnly();
        unzipByLevel();

    }


    /**
     *@Description  读取文本文件明细单，复制到指定目录
     *@param[in/out] null

     *@retval
     *@creator  CaoMingshi
     *@Modify
     *@Date     2024/8/27 22:41
     */
    public static void copyByList() throws IOException {
            String srcDir = "D:\\E_RunDB\\20240705\\0822_CodeReview" ;
            String  absPath ="D:\\E_RunDB\\20240705\\TestCopyList.txt" ;
            String destDir="D:\\E_RunDB\\20240705\\0827" ;

           srcDir = srcDir.replaceAll("(/|\\\\)$","") + File.separator ;
           destDir = destDir.replaceAll("(/|\\\\)$","") + File.separator ;

            FileReader fr = new FileReader(absPath) ;
            BufferedReader br = new BufferedReader(fr);
            String line = null ;
            while((line=br.readLine()) != null){
                 line = line.trim();
                 if(line.length()==0){
                     continue ;
                 }
                line = line.replaceAll("^(/|\\\\)","");
                String absPath1 = srcDir    + line ;
                String absPath2 = destDir + line ;
                File fx = new File(absPath1) ;  //防止文件目录不存在
                if(fx.isDirectory()){                  //如果是目录，复制目录
                    File fx2 = new File(absPath2) ;
                    if(!fx2.exists()){
                        fx2.mkdirs();
                    }
                    continue ;
                }
                else{                                      // 如果是文件，复制文件，但是要准备文件的目录路径
                      File d2 = new File(absPath2);
                      String pAbsPath = d2.getParent() ;
                      File d3 = new File(pAbsPath);
                      if(!d3.exists()){
                          d3.mkdirs();
                      }
                }
                copyFileBytes(absPath1  , absPath2 ) ;
            }

    }

    /**
     *@Description     文件一对一复制
     *@param[in/out] null
     *@retval
     *@creator  CaoMingshi
     *@Modify
     *@Date     2024/8/27 23:07
     */
    public static void copyFileBytes(String srcAbsPath ,String destAbsPath) throws IOException {
           RandomAccessFile raf1 = new RandomAccessFile(srcAbsPath,"rw");
           RandomAccessFile raf2 = new RandomAccessFile(destAbsPath,"rw");
           byte[] bts = new byte[(int)raf1.length()] ;
           raf1.read(bts,0, bts.length) ;
           raf2.write(bts);
           raf1.close();
           raf2.close();
    }


    /**
     *@Description    路径递归遍历
     *@param[in/out] null
     *@retval
     *@creator  CaoMingshi
     *@Modify
     *@Date     2024/8/27 23:07
     */
    public static void recListFiles(String dir){
        File file1 = new File(dir) ;
        if(file1.isDirectory()){
            File[] subFiles = file1.listFiles();
            for (int i = 0; i < subFiles.length; i++) {
                 File fx = subFiles[i];
                 recListFiles(fx.getAbsolutePath()) ;
            }
            System.out.println(file1.getAbsolutePath());
        }
        else{
            System.out.println(file1.getAbsolutePath());
        }
    }

    public static void zipByCrypt() throws IOException, GeneralSecurityException {
        // 被压缩的文件夹
        String sourceFile = "D:\\E_RunDB\\20240705\\0822_CodeReview\\0821";
        // 压缩结果输出，即压缩包
        FileOutputStream fos = new FileOutputStream("D:\\E_RunDB\\20240705\\0822_CodeReview\\dirCompressed.zip");

        // 生成密钥并保存到文件
        SecretKey secretKey = generateKey();
        saveSecretKey(secretKey, "src/main/resources/secret.key");

        // 创建加密密钥
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);

        // 创建加密流
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);

        ZipOutputStream zipOut = new ZipOutputStream(cos);
        File fileToZip = new File(sourceFile);

        // 递归压缩文件夹
        zipFile(fileToZip, fileToZip.getName(), zipOut);

        // 关闭输出流
        zipOut.close();
        fos.close();
    }

    public static void zipByCryptSpec()  throws IOException, GeneralSecurityException {
        // 被压缩的文件夹
        String sourceFile = "D:\\E_RunDB\\20240705\\0822_CodeReview\\0821";
        // 压缩结果输出，即压缩包
        FileOutputStream fos = new FileOutputStream("D:\\E_RunDB\\20240705\\0822_CodeReview\\dirCompressed.zip");

        // 用户指定密码
        String password = "your_password";

        // 生成密钥和参数
        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM2);
        SecretKey secretKey = keyFactory.generateSecret(keySpec);
        byte[] salt = generateSalt();
        PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, ITERATION_COUNT);

        // 创建加密流
        Cipher cipher = Cipher.getInstance(ALGORITHM2);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
        fos.write(salt); // 先将盐值写入文件头，以便解密时使用
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);

        ZipOutputStream zipOut = new ZipOutputStream(cos);
        File fileToZip = new File(sourceFile);
        zipFile(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
        fos.close();
    }

    public static void zipOnly()  throws IOException, GeneralSecurityException {
        // 被压缩的文件夹
        String sourceFile = "D:\\E_RunDB\\20240705\\0822_CodeReview\\0821";
        // 压缩结果输出，即压缩包
        FileOutputStream fos = new FileOutputStream("D:\\E_RunDB\\20240705\\0822_CodeReview\\dirCompressed.zip");

        // 用户指定密码
        String password = "your_password";

        // 生成密钥和参数
        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM2);
        SecretKey secretKey = keyFactory.generateSecret(keySpec);
        byte[] salt = generateSalt();
        PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, ITERATION_COUNT);

        // 创建加密流
        Cipher cipher = Cipher.getInstance(ALGORITHM2);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
        fos.write(salt); // 先将盐值写入文件头，以便解密时使用
        CipherOutputStream cos = new CipherOutputStream(fos, cipher);

        ZipOutputStream zipOut = new ZipOutputStream(cos);
        File fileToZip = new File(sourceFile);
        zipFile(fileToZip, fileToZip.getName(), zipOut);
        zipOut.close();
        fos.close();
    }

    private static void zipFile(File fileToZip, String fileName, ZipOutputStream zipOut) throws IOException {
        if (fileToZip.isHidden()) {
            return;
        }

        if (fileToZip.isDirectory()) {
            if (fileName.endsWith("/")) {
                zipOut.putNextEntry(new ZipEntry(fileName));
                zipOut.closeEntry();
            } else {
                zipOut.putNextEntry(new ZipEntry(fileName + "/"));
                zipOut.closeEntry();
            }

            File[] children = fileToZip.listFiles();
            for (File childFile : children) {
                zipFile(childFile, fileName + "/" + childFile.getName(), zipOut);
            }
            return;
        }

        FileInputStream fis = new FileInputStream(fileToZip);
        ZipEntry zipEntry = new ZipEntry(fileName);
        zipOut.putNextEntry(zipEntry);
        byte[] bytes = new byte[1024];
        int length;
        while ((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
    }


    public static void zipByLevel() throws IOException {
        String sourceDirPath = "D:\\E_RunDB\\20240705\\0827\\0821"; // 源文件夹路径
        String zipFilePath = "D:\\E_RunDB\\20240705\\dirCompressed0830.zip" ;      // 输出ZIP文件路径

        FileOutputStream fos = new FileOutputStream(zipFilePath);
        ZipOutputStream zos = new ZipOutputStream(fos);

        zos.setLevel(Deflater.BEST_COMPRESSION); // 设置最高压缩级别

        File sourceDir = new File(sourceDirPath);
        compressDirectory(sourceDir, sourceDir.getName(), zos);

        zos.close();
        fos.close();
    }


    private static void compressDirectory(File fileToCompress, String fileName, ZipOutputStream zos) throws IOException {
        if (fileToCompress.isHidden()) {
            return;
        }
        if (fileToCompress.isDirectory()) {
            if (fileName.endsWith("/")) {
                zos.putNextEntry(new ZipEntry(fileName));
                zos.closeEntry();
            } else {
                zos.putNextEntry(new ZipEntry(fileName + "/"));
                zos.closeEntry();
            }
            File[] children = fileToCompress.listFiles();
            if (children != null) {
                for (File childFile : children) {
                    compressDirectory(childFile, fileName + "/" + childFile.getName(), zos);
                }
            }
        } else {
            FileInputStream fis = new FileInputStream(fileToCompress);
            ZipEntry zipEntry = new ZipEntry(fileName);
            zos.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) > 0) {
                zos.write(bytes, 0, length);
            }
            zos.flush();
            fis.close();
        }
    }


    private static byte[] generateSalt() {
        byte[] salt = new byte[8];
        SecureRandom sr = new SecureRandom();
        sr.nextBytes(salt);
        return salt;
    }

    private static SecretKey generateKey() throws GeneralSecurityException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
        keyGenerator.init(KEY_SIZE, new SecureRandom());
        return keyGenerator.generateKey();
    }

    private static void saveSecretKey(SecretKey secretKey, String filePath) throws IOException {
        try (FileOutputStream keyOut = new FileOutputStream(filePath)) {
            keyOut.write(secretKey.getEncoded());
        }
    }


    public static void unzipByCrypt() throws IOException, GeneralSecurityException {
        // 被解压的压缩文件
        String fileZip = "D:\\E_RunDB\\20240705\\0822_CodeReview\\dirCompressed.zip";
        // 解压的目标目录
        File destDir = new File("D:\\E_RunDB\\20240705\\0822_CodeReview\\test_unzip");
        String absPathDest = destDir.getAbsolutePath() + File.separator  ;
        System.out.println(destDir.getAbsolutePath());

        // 加载密钥
        SecretKey secretKey = loadSecretKey("src/main/resources/secret.key");

        // 创建解密流
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKey);
        FileInputStream fis = new FileInputStream(fileZip);
        CipherInputStream cis = new CipherInputStream(fis, cipher);
        ZipInputStream zis = new ZipInputStream(cis);

        byte[] buffer = new byte[1024];
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            /*
            File newFile = newFile(destDir, zipEntry);
            FileOutputStream fos = new FileOutputStream(newFile);
            int len;
            while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            */
            System.out.println(zipEntry.toString());
            //准备目录
            if(zipEntry.isDirectory()){
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                if(!f2.exists()){
                    f2.mkdirs();
                }
            }
            else{
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                File f3 = f2.getParentFile() ;
                if(!f3.exists()){
                    f3.mkdirs();
                }
               // File newFile = newFile(destDir, zipEntry);
                //拷贝文件
                FileOutputStream fos = new FileOutputStream(f2);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }

    public static void unzipByCryptSpec() throws IOException, GeneralSecurityException {
        // 被解压的压缩文件
        String fileZip = "D:\\E_RunDB\\20240705\\0830\\pizPwSp.piz.en.ml.rtsrc.cyc.de";
        // 解压的目标目录
        File destDir = new File("D:\\E_RunDB\\20240705\\0830\\unzipPwSp");

        String absPathDest = destDir.getAbsolutePath() + File.separator  ;
        System.out.println(destDir.getAbsolutePath());

        // 用户指定密码
        String password = "your_password";

        // 加载密钥和参数
        FileInputStream fis = new FileInputStream(fileZip);
        byte[] salt = new byte[8];
        fis.read(salt); // 读取文件头的盐值
        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM2);
        SecretKey secretKey = keyFactory.generateSecret(keySpec);
        PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, ITERATION_COUNT);

        // 创建解密流
        Cipher cipher = Cipher.getInstance(ALGORITHM2);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);
        CipherInputStream cis = new CipherInputStream(fis, cipher);
        ZipInputStream zis = new ZipInputStream(cis);

        byte[] buffer = new byte[1024];
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            System.out.println(zipEntry.toString());
            //准备目录
            if(zipEntry.isDirectory()){
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                if(!f2.exists()){
                    f2.mkdirs();
                }
            }
            else{
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                File f3 = f2.getParentFile() ;
                if(!f3.exists()){
                    f3.mkdirs();
                }
                // File newFile = newFile(destDir, zipEntry);
                //拷贝文件
                FileOutputStream fos = new FileOutputStream(f2);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }



    public static void unzipByLevel() throws IOException, GeneralSecurityException {
        // 被解压的压缩文件
        String fileZip = "D:\\E_RunDB\\20240705\\0830\\pizPwSp.piz.en.ml.rtsrc.cyc.de";
        // 解压的目标目录
        File destDir = new File("D:\\E_RunDB\\20240705\\0830\\unzipPwSp");

        String absPathDest = destDir.getAbsolutePath() + File.separator  ;
        System.out.println(destDir.getAbsolutePath());

        FileInputStream fis = new FileInputStream(fileZip);
        ZipInputStream zis = new ZipInputStream(fis);

        byte[] buffer = new byte[1024];
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            System.out.println(zipEntry.toString());
            //准备目录
            if(zipEntry.isDirectory()){
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                if(!f2.exists()){
                    f2.mkdirs();
                }
            }
            else{
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                File f3 = f2.getParentFile() ;
                if(!f3.exists()){
                    f3.mkdirs();
                }
                // File newFile = newFile(destDir, zipEntry);
                //拷贝文件
                FileOutputStream fos = new FileOutputStream(f2);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }





    public static void unzipOnly() throws IOException, GeneralSecurityException {
        // 被解压的压缩文件
        String fileZip = "D:\\E_RunDB\\20240705\\0830\\pizOnly.piz.en.ml.rtsrc.cyc.de";
        // 解压的目标目录
        File destDir = new File("D:\\E_RunDB\\20240705\\0830\\unzip");

        String absPathDest = destDir.getAbsolutePath() + File.separator  ;
        System.out.println(destDir.getAbsolutePath());

        // 用户指定密码
        String password = "your_password";

        // 加载密钥和参数
        FileInputStream fis = new FileInputStream(fileZip);
        /*
        byte[] salt = new byte[8];
        fis.read(salt); // 读取文件头的盐值
        PBEKeySpec keySpec = new PBEKeySpec(password.toCharArray());
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(ALGORITHM2);
        SecretKey secretKey = keyFactory.generateSecret(keySpec);
        PBEParameterSpec parameterSpec = new PBEParameterSpec(salt, ITERATION_COUNT);

        // 创建解密流
        Cipher cipher = Cipher.getInstance(ALGORITHM2);
        cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);
        CipherInputStream cis = new CipherInputStream(fis, cipher);
        ZipInputStream zis = new ZipInputStream(cis);
        */

        ZipInputStream zis = new ZipInputStream(fis);

        byte[] buffer = new byte[1024];
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            System.out.println(zipEntry.toString());
            //准备目录
            if(zipEntry.isDirectory()){
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                if(!f2.exists()){
                    f2.mkdirs();
                }
            }
            else{
                String absPath2 =  absPathDest + zipEntry.toString() ;
                File f2 = new File(absPath2);
                File f3 = f2.getParentFile() ;
                if(!f3.exists()){
                    f3.mkdirs();
                }
                // File newFile = newFile(destDir, zipEntry);
                //拷贝文件
                FileOutputStream fos = new FileOutputStream(f2);
                int len;
                try{
                    while ((len = zis.read(buffer)) >= 0) {
                        fos.write(buffer, 0, len);
                    }
                }catch(Exception e){
                    e.printStackTrace();
                }finally{
                    fos.close();
                }
            }
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }

    private static SecretKey loadSecretKey(String filePath) throws IOException {
        byte[] keyBytes = new byte[16];  // For AES-128
        try (FileInputStream keyIn = new FileInputStream(filePath)) {
            keyIn.read(keyBytes);
        }
        return new SecretKeySpec(keyBytes, ALGORITHM);
    }

    public static File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("该解压项在目标文件夹之外: " + zipEntry.getName());
        }

        return destFile;
    }

}
