package com.cms.raf.mgmt;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: FileSpliter
 * @Package: PACKAGE_NAME ← QuickDone
 * @Description:
 * @Date 2024年02月22日  1:32
 */

public class FileSplitter {

    public static void splitFile(String inputFileName, String outputDir, long chunkSize) {
        try {
            RandomAccessFile inputFile = new RandomAccessFile(inputFileName, "r");
            byte[] buffer = new byte[(int) chunkSize];
            int bytesRead;
            int count = 1;

            File file = new File(inputFileName) ;
            String fileNm = file.getName();

            while ((bytesRead = inputFile.read(buffer)) != -1) {
                String outputFileName = outputDir + "/"+fileNm+"_seg_" + String.format("%03d", count) + ".dat";
                RandomAccessFile outputFile = new RandomAccessFile(outputFileName, "rw");
                outputFile.write(buffer, 0, bytesRead);
                count++;
                outputFile.close();
            }
            inputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void mergeFiles(String[] inputFiles, String outputFileName) {
        try {
            RandomAccessFile outputFile = new RandomAccessFile(outputFileName, "rw");
            long offset = 0;
            for (String inputFile : inputFiles) {
                RandomAccessFile inputFileRAF = new RandomAccessFile(inputFile, "r");
                byte[] buffer = new byte[(int) inputFileRAF.length()];
                inputFileRAF.readFully(buffer);
                outputFile.seek(offset);
                outputFile.write(buffer);
                offset = offset + buffer.length;
                inputFileRAF.close();
            }
            outputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void splitExample(){
      String inputFileName = "Q:\\E_RunDB\\20240705\\kds-nommoc-BE.z7"; // 待分割的文件名
        String outputDir = "Q:\\E_RunDB\\20240705\\"; // 输出目录
        long chunkSize = 1024 * 1024*2 ; // 分割文件的大小（字节数），这里设置为1MB

        splitFile(inputFileName, outputDir, chunkSize);

        /*
        String[] inputFiles = {
                "Q:\\E_WorkCourse\\0001CMSPRJ\\replenish\\0301-0311.7z_seg_001.dat",
                "Q:\\E_WorkCourse\\0001CMSPRJ\\replenish\\0301-0311.7z_seg_002.dat",
                "Q:\\E_WorkCourse\\0001CMSPRJ\\replenish\\0301-0311.7z_seg_003.dat",
                "Q:\\E_WorkCourse\\0001CMSPRJ\\replenish\\0301-0311.7z_seg_004.dat" }; // 分割的文件列表
        String outputFileName = "Q:\\F_开发工具\\数据库相关\\0301-0311.7z"; // 还原的文件名
        mergeFiles(inputFiles, outputFileName);

         */
    }


    public static void splitDefSize(String inputFileName , String outputDir){
        long chunkSize = 1024 * 1024*2 ; // 分割文件的大小（字节数），这里设置为1MB
        splitFile(inputFileName, outputDir, chunkSize);
    }

    public static void main(String[] args) {
        splitExample();
    }
}

