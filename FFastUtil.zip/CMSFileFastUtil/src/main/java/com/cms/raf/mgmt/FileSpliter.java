package com.cms.raf.mgmt;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: FileSpliter
 * @Package:
 * @Description:
 * @Date 2024年02月22日  1:32
 */

public class FileSpliter {

    public static void splitFile(String inputFileName, String outputDir, long chunkSize) {
        try {
            RandomAccessFile inputFile = new RandomAccessFile(inputFileName, "r");
            byte[] buffer = new byte[(int) chunkSize];
            int bytesRead;
            int count = 1;

            File file = new File(inputFileName) ;
            String fileNm = file.getName();

            while ((bytesRead = inputFile.read(buffer)) != -1) {
                String outputFileName = outputDir + "/"+fileNm+"_seg_" + String.format("%03d", count) + ".dat";
                RandomAccessFile outputFile = new RandomAccessFile(outputFileName, "rw");
                outputFile.write(buffer, 0, bytesRead);
                count++;
                outputFile.close();
            }
            inputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void mergeFiles(String[] inputFiles, String outputFileName) {
        try {
            RandomAccessFile outputFile = new RandomAccessFile(outputFileName, "rw");
            long offset = 0;
            for (String inputFile : inputFiles) {
                RandomAccessFile inputFileRAF = new RandomAccessFile(inputFile, "r");
                byte[] buffer = new byte[(int) inputFileRAF.length()];
                inputFileRAF.readFully(buffer);
                outputFile.seek(offset);
                outputFile.write(buffer);
                offset = offset + buffer.length;
                inputFileRAF.close();
            }
            outputFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void splitExample(String absPath4Split , long chunkSize  , String absPathOut ){
        String inputFileName = "D:\\E_WorkCourse\\0001自研项目\\stock_day_full_cap_io_rank_em\\0301-0311.7z"; // 待分割的文件名
        //String outputDir = "absPathOut ;  // 输出目录
        //long chunkSize = 1024 * 1024*18 ; // 分割文件的大小（字节数），这里设置为1MB
        splitFile(inputFileName, absPathOut, chunkSize);
    }
    public static String mergeExample(String[] inputFiles){
        String absPathRet = inputFiles[0]+".mg" ;
        for (int i = 0; i < absPathRet.length() ;  i++) {
            mergeFiles(inputFiles, absPathRet);
        }
        return absPathRet ;
    }
    public static void main(String[] args) {
        //splitExample();

        String absPaths[] ={
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_001.dat.en.ml.rtsrc.cyc.de",
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_002.dat.en.ml.rtsrc.cyc.de",
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_003.dat.en.ml.rtsrc.cyc.de",
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_004.dat.en.ml.rtsrc.cyc.de",
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_005.dat.en.ml.rtsrc.cyc.de",
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_006.dat.en.ml.rtsrc.cyc.de",
                "D:\\E_RunDB\\0904\\doc\\uuu.vvv_sg_007.dat.en.ml.rtsrc.cyc.de"
        };
        String absPathRet = mergeExample(absPaths) ;
        System.out.println(absPathRet);

    }
}

