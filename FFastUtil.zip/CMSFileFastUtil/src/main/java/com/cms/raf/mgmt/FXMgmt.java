package com.cms.raf.mgmt;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.Set;

import static com.cms.raf.mgmt.FileZipUtil.zip2Mem;

/**
 * @author CaoMingshi
 * @version V1.0
 * @Title: FXMgmt
 * @Package: com.cms.raf.mgmt ← CMSFileFastUtil
 * @Description:
 * @Date 2024年09月13日  21:51
 */
public class FXMgmt {
    public static String RUN_MNT_PATH = null ;
    public static String DOEN_FLAG = null ;
    public static String INPUT_DIR = null ;
    public static String OUTPUT_PATH = null ;
    public static String OUTPUT_Z_FILE = null ;

    public static String DODE_ML_FLAG = null ;
    public static String DODE_FROM_FLAG = null ;
    public static String ML_LIST = null ;
    public static String ML_DIR = null ;

    public static String DOSPLIT_FLAG = null ;
    public static String SPLIT_ABS_PATH = null ;
    public static String SPLIT_OPF = null ;

    public static  final  LinkedHashMap<String, ArrayList<String>> INIT_LHM = new LinkedHashMap<String, ArrayList<String>>();
    public  static  final Properties props = new Properties();
    public static void main(String[] args) throws IOException {
        if(!initEnv(args)){
            System.exit(-1) ;
        }

       if("1".equals(DOEN_FLAG)){
           byte[] bts = zip2Mem(INPUT_DIR);
           String absPathZip = OUTPUT_PATH.replaceAll("(\\\\|/)$","") + File.separator + OUTPUT_Z_FILE ;
           System.out.println(absPathZip);
           RandomAccessFile raf = new RandomAccessFile(absPathZip,"rw") ;
           raf.write(bts);
           raf.close();
           FileFastSimpleEnDecrypt.makeMLTxtByBytes( absPathZip ,  bts ) ;
       }
       if("1".equals(DODE_ML_FLAG))
       {
           String ss[] = {

           } ;
           if("1".equals(DODE_FROM_FLAG)){
               ss = new String[1] ;
               ss[0] = OUTPUT_PATH.replaceAll("(\\\\|/)$","") + File.separator + OUTPUT_Z_FILE +".ml" ;  //带路径的 eg :D:/E_RunDB/20240705/0912_output_test/aaa.zip.ml
           }
           else if(ML_LIST != null && ML_LIST.length() >0)
           {
               ss  = ML_LIST.split(",");
           }
           String dirTmp = "./" ;

           if(ML_DIR != null && ML_DIR.length() >0)
           {
               ML_DIR = ML_DIR.replaceAll("(\\\\|/)$","") + File.separator ;
               dirTmp = ML_DIR ;
               if("2".equals(DODE_FROM_FLAG)) {  //  using ml list  not from living zipened
                   for (int i = 0; i < ss.length; i++) {
                       ss[i] = dirTmp + ss[i];
                   }
               }
           }
           for (int i = 0; i < ss.length ; i++) {
               String absPathEnML =ss[i]  ;
               try {
                   String  absPathRtrSrc = FileFastSimpleEnDecrypt.retriveMatrix(absPathEnML);
                   String  absPathCycDe = FileFastSimpleEnDecrypt.decryptFile(FileFastSimpleEnDecrypt.getKEY() ,  absPathRtrSrc);
                   System.out.println("absPathCycDe-->"+absPathCycDe);
               } catch (Exception e) {
                   e.printStackTrace();
               }
           }
       }

       if("1".equals(DOSPLIT_FLAG))
       {
           if(SPLIT_ABS_PATH  != null && SPLIT_ABS_PATH.length() >0
                && SPLIT_OPF != null  && SPLIT_OPF.length() >0)
           {
               FileSplitter.splitDefSize(SPLIT_ABS_PATH,SPLIT_OPF);
           }
       }
    }

    public static boolean initEnv(String[] args) throws IOException {


        for (int i = 0; i < args.length; i++) {
            System.out.println("args[" + i + "]=" + args[i]);
            distinguishArgs(INIT_LHM, args[i]);
        }

        //0、环境测试
        System.out.println("distinguishArgs(lhm , ~ )=" + INIT_LHM.toString());
        Object getResource = FXMgmt.class.getResource(".") ;
        System.out.println("com.cms.raf.mgmt.class.FXMgmt.getResource(\".\")-->"+getResource);

        String jarFilePath = FXMgmt.class.getProtectionDomain().getCodeSource().getLocation().getPath();
        System.out.println("jarFilePath-->"+jarFilePath);
        jarFilePath =  jarFilePath.replaceAll("[/\\\\][^/\\\\]+$", "");
        System.out.println("jarFilePath2-->"+jarFilePath);

        //1、传入参数个数校验
        if (INIT_LHM.get("cfgfile") ==null || INIT_LHM.get("cfgfile").size()==0 ) {
            System.err.println("wrong args , eg: -cfgfile CPS_ENV_AND_EXE.ini");
            return false ;
        }

        //2、根据第1个参数获取配置文件路径
        String cfgFileName = INIT_LHM.get("cfgfile").get(0).trim();
        if (cfgFileName == null || cfgFileName.equals("")) {
            System.err.println("cfgfile param must be an exist ini file");
            return false ;
        }
        else{
            System.out.println("cfgfile param OK ");
        }

        if(!readInitFile(cfgFileName)){
            System.out.println("init File  read Failed ! please check ! ");
            return false  ;
        }
        return true ;
    }


    public static void distinguishArgs(LinkedHashMap<String, ArrayList<String>> lhm, String arg) {
        String currArgKey = null ;
        if (arg.trim().indexOf("-") ==0) {  //如果为参数key
            arg = arg.replaceAll("^-+", "");

            //01、存取 LAST_APPEARED_KEY元数据
            ArrayList<String> arr = new ArrayList<String>();
            arr.add(arg);
            //给当前key标记成最后一个key , 以内LinkedHashMap 没有快捷获取最后一个key的方法 ,在LinkedHashMap头放一个元数据，专门存放 lastkey
            // {key , value[X,X,...] , key , value[X,X,...] ,key , value[X,X,...] }
            lhm.put("LAST_\037APPEARED\037_KEY",arr);

            //02、存取当前key值
            ArrayList<String> values = lhm.get(arg);
            if (values != null) { //如果已经加过参数，继续追加
                //values.add(arg);
            }
            else { //否则开辟新参数键值对，加空值
                values = new ArrayList<String>();
                lhm.put(arg, values);
            }
        }
        else { //03、如果不是参数key ,是参数value
            if (lhm.size() == 0) { //舍弃
                return;
            }
            String key = null;
            ArrayList<String> arr = null;
            //获取最后出现的不考虑重复时候的参数key , 防止 最后一个参数key前 有空value 的 key出现
            if(lhm.get("LAST_\037APPEARED\037_KEY") !=null){
                ArrayList<String> lastArr= lhm.get("LAST_\037APPEARED\037_KEY");

                //获取最后一个参数值的的存放容器
                arr = lhm.get(lastArr.get(0));
                for(String s:arr){
                    if(s.equals(arg)){  //查找是否有重复的值
                        return;
                    }
                }
                arr.add(arg);
                lhm.put(lastArr.get(0),arr) ;
                return ;
            }
        }
    }

    private static boolean readInitFile( String strFileName) throws IOException {

        System.out.println("读取readInitFile--->"+strFileName);
        InputStream in = null ;
        File file = new File(strFileName) ;

        //优先包外绝对路径
        if(file.exists()){
            in = new FileInputStream(strFileName) ;
        }
        else{
            in = Thread.currentThread().getContextClassLoader().getResourceAsStream(strFileName) ;
        }
        InputStreamReader isr = new InputStreamReader(in, "utf-8") ;
        props.load(isr);
        in.close();

        Set<Object> keySet = props.keySet();
        String tmpText = null ;

        try {
            RUN_MNT_PATH= props.getProperty("RUN_MNT_PATH").trim() ;
            System.out.println("loaded RUN_MNT_PATH="+props.getProperty("RUN_MNT_PATH"));
        } catch (Exception e) {
            System.out.println("ini RUN_MNT_PATH is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(RUN_MNT_PATH == null ){
                System.out.println("ini not set RUN_MNT_PATH " );
                return false ;
            }
        }

        try {
            DOEN_FLAG= props.getProperty("DOEN_FLAG").trim() ;
            System.out.println("loaded DOEN_FLAG="+props.getProperty("DOEN_FLAG"));
        } catch (Exception e) {
            System.out.println("ini DOEN_FLAG is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(DOEN_FLAG == null ){
                System.out.println("ini not set DOEN_FLAG " );
                return false ;
            }
        }


        try {
            INPUT_DIR= props.getProperty("INPUT_DIR").trim() ;
            System.out.println("loaded INPUT_DIR="+props.getProperty("INPUT_DIR"));
        } catch (Exception e) {
            System.out.println("ini INPUT_DIR is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(INPUT_DIR == null ){
                System.out.println("ini not set INPUT_DIR " );
                return false ;
            }
        }


        try {
            OUTPUT_PATH= props.getProperty("OUTPUT_PATH").trim() ;
            System.out.println("loaded OUTPUT_PATH="+props.getProperty("OUTPUT_PATH"));
        } catch (Exception e) {
            System.out.println("ini OUTPUT_PATH is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(OUTPUT_PATH == null ){
                System.out.println("ini not set OUTPUT_PATH " );
                return false ;
            }
        }

        try {
            OUTPUT_Z_FILE= props.getProperty("OUTPUT_Z_FILE").trim() ;
            System.out.println("loaded OUTPUT_Z_FILE="+props.getProperty("OUTPUT_Z_FILE"));
        } catch (Exception e) {
            System.out.println("ini OUTPUT_Z_FILE is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(OUTPUT_Z_FILE == null ){
                System.out.println("ini not set OUTPUT_Z_FILE " );
                return false ;
            }
        }

        try {
            DODE_ML_FLAG= props.getProperty("DODE_ML_FLAG").trim() ;
            System.out.println("loaded DODE_ML_FLAG="+props.getProperty("DODE_ML_FLAG"));
        } catch (Exception e) {
            System.out.println("ini DODE_ML_FLAG is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(DODE_ML_FLAG == null ){
                System.out.println("ini not set DODE_ML_FLAG " );
                return false ;
            }
        }

        try {
            DODE_FROM_FLAG = props.getProperty("DODE_FROM_FLAG").trim() ;
            System.out.println("loaded DODE_FROM_FLAG="+props.getProperty("DODE_FROM_FLAG"));
        } catch (Exception e) {
            System.out.println("ini DODE_FROM_FLAG is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(DODE_FROM_FLAG == null ){
                System.out.println("ini not set DODE_FROM_FLAG " );
                return false ;
            }
        }


        try {
            ML_LIST= props.getProperty("ML_LIST").trim() ;
            System.out.println("loaded ML_LIST="+props.getProperty("ML_LIST"));
        } catch (Exception e) {
            System.out.println("ini ML_LIST is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(ML_LIST == null ){
                System.out.println("ini not set ML_LIST " );
                return false ;
            }
        }

        try {
            ML_DIR= props.getProperty("ML_DIR").trim() ;
            System.out.println("loaded ML_DIR="+props.getProperty("ML_DIR"));
        } catch (Exception e) {
            System.out.println("ini ML_DIR is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(ML_DIR == null ){
                System.out.println("ini not set ML_DIR " );
                return false ;
            }
        }

        try {
            DOSPLIT_FLAG= props.getProperty("DOSPLIT_FLAG").trim() ;
            System.out.println("loaded DOSPLIT_FLAG="+props.getProperty("DOSPLIT_FLAG"));
        } catch (Exception e) {
            System.out.println("ini DOSPLIT_FLAG is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(DOSPLIT_FLAG == null ){
                System.out.println("ini not set DOSPLIT_FLAG " );
                return false ;
            }
        }

        try {
            SPLIT_ABS_PATH= props.getProperty("SPLIT_ABS_PATH").trim() ;
            System.out.println("loaded SPLIT_ABS_PATH="+props.getProperty("SPLIT_ABS_PATH"));
        } catch (Exception e) {
            System.out.println("ini SPLIT_ABS_PATH is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(SPLIT_ABS_PATH == null ){
                System.out.println("ini not set SPLIT_ABS_PATH " );
                return false ;
            }
        }

        try {
            SPLIT_OPF= props.getProperty("SPLIT_OPF").trim() ;
            System.out.println("loaded SPLIT_OPF="+props.getProperty("SPLIT_OPF"));
        } catch (Exception e) {
            System.out.println("ini SPLIT_OPF is not set a correcttly : "+getStackTrace(e)) ;
            return false ;
        }finally{
            if(SPLIT_OPF == null ){
                System.out.println("ini not set SPLIT_OPF " );
                return false ;
            }
        }

        return  true ;
    }

    public static String getStackTrace(Exception e){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        e.printStackTrace(pw);
        String stackTrace = sw.toString();
        return stackTrace ;
    }
}
